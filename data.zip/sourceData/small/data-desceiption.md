# The description for the small scale instances

“***n***” denotes the number of the total customers

"***m***" denotes the number of the FCs

"***kt***" denotes the number of  the combination truck

"***ut***" denotes the number of the pure truck

"**Q1**" denotes the capacity of the combination truck

"***Q2***" denotes the capacity of the pure truck

"**q**" denotes the cargo demand of all customers

"**s**" denotes the service time needed by all customers

"**e**" and "**l**" denote the lower and upper bound of the customers' time windows

"**d**" denotes the Euclidean distance for all the vertices in the network







