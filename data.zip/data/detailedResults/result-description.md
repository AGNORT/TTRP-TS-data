# The source data and the detailed results for the TTRP-TS

The detailed computational results for both small and large-scale instances are presented in the following format:

"**Route\*:** " indicates the route indexed by "*" with subsequent sequence information.

"**Swap operation:**" provides the swap plan for emptied trailers in each instance. The statement "No emptied trailers swap operation!" signifies the absence of emptied trailer swaps in the optimal solution.

"**Cost:**" indicates the cost of the best solution discovered.


