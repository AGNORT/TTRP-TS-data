# The description for the small scale instances

“***n***” denotes the number of customers

"***m***" denotes the number of FCs

"***kt***" denotes the number of  combination trucks

"***ut***" denotes the number of pure trucks

"**Q1**" denotes the capacity of the combination truck

"***Q2***" denotes the capacity of the pure truck

"**q**" denotes the cargo demand of customers

"**s**" denotes the service time needed by customers

"**e**" and "**l**" denote the lower and upper bound of the customers' time windows

"**d**" denotes the Euclidean distance for all the vertices in the network







